﻿using System.Collections.Generic;
using System.Threading.Tasks;
using DeloitteTechTest.Clients;
using DeloitteTechTest.Factories;
using DeloitteTechTest.Models;
using DeloitteTechTest.Queries;
using DeloitteTechTest.Services;
using FluentAssertions;
using Moq;
using NUnit.Framework;

namespace DeloitteTechTestUnitTests.Services
{
    [TestFixture()]
    public class HotelServiceTests
    {
        private Mock<IHotelApiClient> _mockHotelApiClient;
        private Mock<IHotelCache> _mockHotelCache;
        private Mock<IHotelsQueryFactory> _mockHotelsQueryFactory;
        private List<HotelModel> _hotels;

        [SetUp]
        public void Setup()
        {
            _mockHotelApiClient = new Mock<IHotelApiClient>();
            _mockHotelCache = new Mock<IHotelCache>();
            _mockHotelsQueryFactory = new Mock<IHotelsQueryFactory>();

            _hotels = new List<HotelModel>
            {
                new()
                {
                    Name = "Golden Sword Resort",
                    Description = "Golden Sword Resort",
                    Location = "London",
                    Rating = 3.8
                },
                new()
                {
                    Name = "Private Fjord Hotel & Spa",
                    Description = "Private Fjord Hotel & Spa",
                    Location = "London",
                    Rating = 4.1
                },
                new()
                {
                    Name = "Scarlet Grotto Hotel",
                    Description = "Scarlet Grotto Hotel",
                    Location = "London",
                    Rating = 3.1
                }
            };
        }

        [Test()]
        public async Task GetHotels_Returns_AllHotels_FromCache()
        {
            var mockQuery = new Mock<IHotelsQuery>();
            mockQuery.Setup(q => q.ByName(null)).Returns(mockQuery.Object);
            mockQuery.Setup(q => q.ByRating(null)).Returns(mockQuery.Object);
            mockQuery.Setup(q => q.SortByRating(null)).Returns(mockQuery.Object);
            mockQuery.Setup(q => q.Result).Returns(_hotels);
            _mockHotelsQueryFactory.Setup(q => q.Create(_hotels)).Returns(mockQuery.Object);

            _mockHotelCache.Setup(c => c.GetHotelsData()).Returns(_hotels);

            var controller = new HotelService(_mockHotelApiClient.Object, _mockHotelCache.Object,
                _mockHotelsQueryFactory.Object);
            var result = await controller.GetHotels(null, null, null);

            result.Should().BeSameAs(_hotels);
        }

        [Test()]
        public async Task GetHotels_Returns_AllHotels_FromApiClient()
        {
            var mockQuery = new Mock<IHotelsQuery>();
            mockQuery.Setup(q => q.ByName(null)).Returns(mockQuery.Object);
            mockQuery.Setup(q => q.ByRating(null)).Returns(mockQuery.Object);
            mockQuery.Setup(q => q.SortByRating(null)).Returns(mockQuery.Object);
            mockQuery.Setup(q => q.Result).Returns(_hotels);
            _mockHotelsQueryFactory.Setup(q => q.Create(_hotels)).Returns(mockQuery.Object);

            _mockHotelCache.Setup(c => c.GetHotelsData()).Returns(new List<HotelModel>());
            _mockHotelApiClient.Setup(c => c.GetHotelsData()).ReturnsAsync(_hotels);

            var controller = new HotelService(_mockHotelApiClient.Object, _mockHotelCache.Object,
                _mockHotelsQueryFactory.Object);
            var result = await controller.GetHotels(null, null, null);

            result.Should().BeSameAs(_hotels);
            _mockHotelCache.Verify(c => c.PopulateHotelsData(_hotels), Times.Once);
        }
    }
}