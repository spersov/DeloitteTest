﻿using System.Collections.Generic;
using System.Threading.Tasks;
using DeloitteTechTest.Controllers;
using DeloitteTechTest.Models;
using DeloitteTechTest.Services;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;

namespace DeloitteTechTestUnitTests.Controllers
{
    [TestFixture()]
    public class HotelsControllerTests
    {
        [Test()]
        public async Task Get_OnInvoke_Returns_AllHotels()
        {
            var hotels = new List<HotelModel>
            {
                new()
                {
                    Name = "Golden Sword Resort",
                    Description = "Golden Sword Resort",
                    Location = "London",
                    Rating = 3.8
                },
                new()
                {
                    Name = "Private Fjord Hotel & Spa",
                    Description = "Private Fjord Hotel & Spa",
                    Location = "London",
                    Rating = 4.1
                },
                new()
                {
                    Name = "Scarlet Grotto Hotel",
                    Description = "Scarlet Grotto Hotel",
                    Location = "London",
                    Rating = 3.1
                }
            };
            var mockHotelService = new Mock<IHotelService>();
            mockHotelService.Setup(h => h.GetHotels(null, null, null)).ReturnsAsync(hotels);
            var controller = new HotelsController(mockHotelService.Object);

            var result = (await controller.Get(null, null, null)).Result as OkObjectResult;

            result.StatusCode.Should().Be(StatusCodes.Status200OK);
            result.Value.Should().BeOfType<List<HotelModel>>();
            result.Value.Should().Be(hotels);
            mockHotelService.Verify(c => c.GetHotels(null, null, null), Times.Once);
        }
    }
}