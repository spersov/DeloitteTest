﻿using System.Collections.Generic;
using System.Linq;
using DeloitteTechTest.Models;
using DeloitteTechTest.Queries;
using FluentAssertions;
using NUnit.Framework;

namespace DeloitteTechTestUnitTests.Queries
{
    [TestFixture()]
    public class HotelsQueryTests
    {
        private List<HotelModel> _inputHotels = new();

        [SetUp]
        public void Setup()
        {
            _inputHotels = new List<HotelModel>
            {
                new()
                {
                    Name = "Golden Sword Resort",
                    Description = "Golden Sword Resort",
                    Location = "London",
                    Rating = 3.8
                },
                new()
                {
                    Name = "Private Fjord Hotel & Spa",
                    Description = "Private Fjord Hotel & Spa",
                    Location = "London",
                    Rating = 4.1
                },
                new()
                {
                    Name = "Scarlet Grotto Hotel",
                    Description = "Scarlet Grotto Hotel",
                    Location = "London",
                    Rating = 3.1
                }
            };
        }

        [Test()]
        public void ByName_Returns_HotelsByName()
        {
            var query = new HotelsQuery(_inputHotels);
            var result = query.ByName("Hotel");
            result.Should().BeSameAs(query);
            result.Result.All(h => h.Name.Contains("Hotel")).Should().BeTrue();
        }

        [Test()]
        public void ByRating_Returns_HotelsByRating()
        {
            var query = new HotelsQuery(_inputHotels);
            var result = query.ByRating(3);
            result.Should().BeSameAs(query);
            result.Result.All(h => (int) h.Rating == 3).Should().BeTrue();
        }

        [Test()]
        public void SortByRating_Returns_HotelsInDescendingOrder()
        {
            var query = new HotelsQuery(_inputHotels);
            var result = query.SortByRating(true);
            result.Should().BeSameAs(query);
            result.Result.SequenceEqual(_inputHotels.OrderByDescending(h => h.Rating)).Should().BeTrue();
        }
    }
}