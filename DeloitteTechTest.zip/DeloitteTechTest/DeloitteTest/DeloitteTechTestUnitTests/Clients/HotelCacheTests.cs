﻿using System.Collections.Generic;
using DeloitteTechTest.Clients;
using DeloitteTechTest.Models;
using FluentAssertions;
using NUnit.Framework;

namespace DeloitteTechTestUnitTests.Clients
{
    [TestFixture()]
    public class HotelCacheTests
    {
        [Test()]
        public void GetHotelsData_ReturnsEmptyList()
        {
            var cache = new HotelCache();
            var result = cache.GetHotelsData();

            result.Should().BeOfType<List<HotelModel>>();
            result.Should().HaveCount(0);
        }

        [Test()]
        public void PopulateHotelsData_PopulatesHotelsData()
        {
            var hotels = new List<HotelModel>
            {
                new()
                {
                    Name = "Golden Sword Resort",
                    Description = "Golden Sword Resort",
                    Location = "London",
                    Rating = 3.8
                },
                new()
                {
                    Name = "Private Fjord Hotel & Spa",
                    Description = "Private Fjord Hotel & Spa",
                    Location = "London",
                    Rating = 4.1
                },
                new()
                {
                    Name = "Scarlet Grotto Hotel",
                    Description = "Scarlet Grotto Hotel",
                    Location = "London",
                    Rating = 3.1
                }
            };

            var cache = new HotelCache();
            cache.PopulateHotelsData(hotels);
            var result = cache.GetHotelsData();

            result.Should().BeSameAs(hotels);
        }
    }
}