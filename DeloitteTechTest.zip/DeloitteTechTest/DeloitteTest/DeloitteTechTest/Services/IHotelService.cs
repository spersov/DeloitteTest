﻿#nullable enable
using System.Collections.Generic;
using System.Threading.Tasks;
using DeloitteTechTest.Models;

namespace DeloitteTechTest.Services
{
    public interface IHotelService
    {
        public Task<List<HotelModel>> GetHotels(string? name, int? selectedRating, bool? sortByRating);
    }
}