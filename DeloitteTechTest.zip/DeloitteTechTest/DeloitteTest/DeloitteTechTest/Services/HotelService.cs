﻿#nullable enable
using System.Collections.Generic;
using System.Threading.Tasks;
using DeloitteTechTest.Clients;
using DeloitteTechTest.Factories;
using DeloitteTechTest.Models;
using DeloitteTechTest.Queries;

namespace DeloitteTechTest.Services
{
    public class HotelService : IHotelService
    {
        private readonly IHotelApiClient _hotelApiClient;
        private readonly IHotelCache _hotelCache;
        private readonly IHotelsQueryFactory _hotelsQueryFactory;

        public HotelService(IHotelApiClient hotelApiClient, IHotelCache hotelCache,
            IHotelsQueryFactory hotelsQueryFactory)
        {
            _hotelApiClient = hotelApiClient;
            _hotelCache = hotelCache;
            _hotelsQueryFactory = hotelsQueryFactory;
        }

        public async Task<List<HotelModel>> GetHotels(string? name, int? selectedRating, bool? sortByRating)
        {
            var hotels = _hotelCache.GetHotelsData();

            if (hotels.Count == 0)
            {
                hotels = await _hotelApiClient.GetHotelsData();
                _hotelCache.PopulateHotelsData(hotels);
            }

            IHotelsQuery query = _hotelsQueryFactory.Create(hotels)
                .ByName(name)
                .ByRating(selectedRating)
                .SortByRating(sortByRating);

            return query.Result;
        }
    }
}