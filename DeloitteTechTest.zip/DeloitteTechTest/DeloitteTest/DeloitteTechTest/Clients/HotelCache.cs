﻿using System.Collections.Generic;
using DeloitteTechTest.Models;

namespace DeloitteTechTest.Clients
{
    public class HotelCache : IHotelCache
    {
        private List<HotelModel> Hotels { get; set; } = new();
        private readonly object _hotelsLock = new();

        public List<HotelModel> GetHotelsData()
        {
            lock (_hotelsLock)
            {
                return Hotels;
            }
        }

        public void PopulateHotelsData(List<HotelModel> hotels)
        {
            lock (_hotelsLock)
            {
                Hotels = hotels;
            }
        }
    }
}