﻿using System.Collections.Generic;
using DeloitteTechTest.Models;

namespace DeloitteTechTest.Clients
{
    public interface IHotelCache
    {
        public List<HotelModel> GetHotelsData();
        public void PopulateHotelsData(List<HotelModel> hotels);
    }
}