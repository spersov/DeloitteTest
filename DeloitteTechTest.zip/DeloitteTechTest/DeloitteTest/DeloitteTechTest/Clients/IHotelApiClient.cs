﻿using System.Collections.Generic;
using System.Threading.Tasks;
using DeloitteTechTest.Models;

namespace DeloitteTechTest.Clients
{
    public interface IHotelApiClient
    {
        public Task<List<HotelModel>> GetHotelsData();
    }
}