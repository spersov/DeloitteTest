﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using DeloitteTechTest.Models;
using Newtonsoft.Json;
using Polly;

namespace DeloitteTechTest.Clients
{
    public class HotelApiClient : IHotelApiClient
    {
        public async Task<List<HotelModel>> GetHotelsData()
        {
            var policy = Policy
                .Handle<Exception>()
                .WaitAndRetryAsync(3, retryAttempt =>
                    TimeSpan.FromMilliseconds(Math.Pow(2, retryAttempt)));
            string resultsStream = null;
            await policy.ExecuteAsync(async () =>
            {
                using var resultsStreamer = new StreamReader("./hotels.json");
                resultsStream = await resultsStreamer.ReadToEndAsync();
            });


            return JsonConvert.DeserializeObject<List<HotelModel>>(resultsStream);
        }
    }
}