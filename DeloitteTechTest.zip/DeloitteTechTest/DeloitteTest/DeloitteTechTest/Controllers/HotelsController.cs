﻿#nullable enable
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using DeloitteTechTest.Models;
using DeloitteTechTest.Services;

namespace DeloitteTechTest.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HotelsController : ControllerBase
    {
        private readonly IHotelService _hotelService;

        public HotelsController(IHotelService hotelService)
        {
            _hotelService = hotelService;
        }

        [HttpGet]
        public async Task<ActionResult<List<HotelModel>>> Get(string? name, int? selectedRating,
            bool? sortByRating)
        {
            var hotels = await _hotelService.GetHotels(name, selectedRating, sortByRating);
            return Ok(hotels);
        }
    }
}