﻿using System.Collections.Generic;
using DeloitteTechTest.Models;
using DeloitteTechTest.Queries;

namespace DeloitteTechTest.Factories
{
    internal class HotelsQueryFactory : IHotelsQueryFactory
    {
        public IHotelsQuery Create(List<HotelModel> hotels)
        {
            return new HotelsQuery(hotels);
        }
    }
}