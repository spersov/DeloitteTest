﻿using System.Collections.Generic;
using DeloitteTechTest.Models;
using DeloitteTechTest.Queries;

namespace DeloitteTechTest.Factories
{
    public interface IHotelsQueryFactory
    {
        public IHotelsQuery Create(List<HotelModel> hotels);
    }
}