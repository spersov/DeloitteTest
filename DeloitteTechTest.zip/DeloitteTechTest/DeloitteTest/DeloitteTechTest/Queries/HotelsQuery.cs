﻿using System.Collections.Generic;
using System.Linq;
using DeloitteTechTest.Models;

namespace DeloitteTechTest.Queries
{
    public class HotelsQuery : IHotelsQuery
    {
        private List<HotelModel> _hotels;

        public HotelsQuery(List<HotelModel> hotels)
        {
            _hotels = hotels;
        }

        public IHotelsQuery ByName(string? name)
        {
            if (name != null)
            {
                _hotels = _hotels.Where(h => h.Name.ToLower().Contains(name.ToLower())).ToList();
            }

            return this;
        }

        public IHotelsQuery ByRating(int? rating)
        {
            if (rating != null)
            {
                _hotels = _hotels.Where(h => (int) h.Rating == rating).ToList();
            }

            return this;
        }

        public IHotelsQuery SortByRating(bool? shouldSortByRating)
        {
            if (shouldSortByRating != null && shouldSortByRating.Value)
            {
                _hotels = _hotels.OrderByDescending(h => h.Rating).ToList();
            }

            return this;
        }

        public List<HotelModel> Result => _hotels;
    }
}