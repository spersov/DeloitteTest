﻿using System.Collections.Generic;
using DeloitteTechTest.Models;

namespace DeloitteTechTest.Queries
{
    public interface IHotelsQuery
    {
        IHotelsQuery ByName(string? name);

        IHotelsQuery ByRating(int? rating);

        IHotelsQuery SortByRating(bool? shouldSortByRating);

        List<HotelModel> Result { get; }
    }
}